package com.meuclient.mixin;

import com.meuclient.modules.VaultSniper;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Quando o servidor atualiza uma caixa (vault), os modulos de vault reagem na hora. */
@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    // require = 0: se o metodo mudar de nome, o client abre normal (so perde essa resposta instantanea)
    @Inject(method = "onBlockEntityUpdate", at = @At("TAIL"), require = 0)
    private void ninjaclient$onVaultUpdate(BlockEntityUpdateS2CPacket packet, CallbackInfo ci) {
        VaultSniper.onVaultPacket();
    }
}
