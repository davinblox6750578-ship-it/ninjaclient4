package com.meuclient.modules;

import net.minecraft.item.Items;

/**
 * PotVault: caixa NORMAL (vault comum) das Trial Chambers.
 * Quando o item flutuando e a POCAO DE MAL PRESSAGIO (ominous bottle) e voce
 * tem a CHAVE NORMAL (trial key) na hotbar, clica na caixa na hora. A pocao
 * serve para ativar uma trial suprema e conseguir a chave suprema.
 */
public class PotVault extends VaultSniper {
    public PotVault() {
        super("PotVault", false, Items.OMINOUS_BOTTLE, Items.TRIAL_KEY, 4);
    }
}
