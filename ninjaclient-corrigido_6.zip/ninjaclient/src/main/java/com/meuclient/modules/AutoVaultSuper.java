package com.meuclient.modules;

import net.minecraft.item.Items;

/**
 * AutoVaultSuper: caixa misteriosa SUPREMA (ominous vault).
 * Quando o item flutuando e o NUCLEO PESADO (heavy core, da clava) e voce tem
 * a CHAVE SUPREMA (ominous trial key) na hotbar, clica na caixa na hora.
 */
public class AutoVaultSuper extends VaultSniper {
    public AutoVaultSuper() {
        super("AutoVaultSuper", true, Items.HEAVY_CORE, Items.OMINOUS_TRIAL_KEY, 4);
    }
}
