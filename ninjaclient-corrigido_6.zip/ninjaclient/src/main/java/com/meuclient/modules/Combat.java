package com.meuclient.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Funcoes compartilhadas pelos modulos de combate. */
public final class Combat {
    private Combat() {}

    public static PlayerEntity nearestPlayer(MinecraftClient mc, double range) {
        return nearestPlayer(mc, range, false);
    }

    /** Se requireSight for true, ignora jogadores escondidos atras de blocos. */
    public static PlayerEntity nearestPlayer(MinecraftClient mc, double range, boolean requireSight) {
        PlayerEntity best = null;
        double bestDist = range;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            if (requireSight && !mc.player.canSee(p)) continue;
            double d = mc.player.distanceTo(p);
            if (d <= bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    /** Barra de cooldown padrao: 90%. */
    public static final float DEFAULT_COOLDOWN = 0.90f;

    public static boolean cooldownReady(MinecraftClient mc) {
        return mc.player.getAttackCooldownProgress(0.5f) >= DEFAULT_COOLDOWN;
    }

    /** Distancia de um ponto (olhos) ate a caixa de colisao do alvo - e assim que o servidor mede o alcance. */
    public static double distanceToBox(Vec3d p, Box b) {
        double x = Math.max(Math.max(b.minX - p.x, 0), p.x - b.maxX);
        double y = Math.max(Math.max(b.minY - p.y, 0), p.y - b.maxY);
        double z = Math.max(Math.max(b.minZ - p.z, 0), p.z - b.maxZ);
        return Math.sqrt(x * x + y * y + z * z);
    }

    /** Jogador vivo mais perto cuja CAIXA esta dentro do alcance (olhos -> caixa). */
    public static PlayerEntity nearestPlayerInReach(MinecraftClient mc, double reach) {
        Vec3d eye = mc.player.getEyePos();
        PlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.player) continue;
            if (!p.isAlive() || p.isSpectator() || p.isInvulnerable()) continue;
            double d = distanceToBox(eye, p.getBoundingBox());
            if (d <= reach && d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    /** Ataca quando a barra de cooldown estiver pelo menos em `minProgress` (0.0 a 1.0). */
    public static boolean cooldownReady(MinecraftClient mc, float minProgress) {
        return mc.player.getAttackCooldownProgress(0.5f) >= minProgress;
    }

    public static void attack(MinecraftClient mc, Entity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    /** Gira a camera ate o alvo (olhos), no maximo `maxStep` graus por tick. */
    public static void aimAt(MinecraftClient mc, Entity target, float maxStep) {
        aimAtPos(mc, target.getEyePos(), maxStep);
    }

    /** Gira a camera ate um ponto qualquer, no maximo `maxStep` graus por tick. */
    public static void aimAtPos(MinecraftClient mc, Vec3d to, float maxStep) {
        Vec3d from = mc.player.getEyePos();
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        float dYaw = MathHelper.wrapDegrees(yaw - mc.player.getYaw());
        float dPitch = pitch - mc.player.getPitch();
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(dYaw, -maxStep, maxStep));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(dPitch, -maxStep, maxStep), -90f, 90f));
    }

    /**
     * Ataque com mira silenciosa: avisa o servidor que voce olhou para o alvo,
     * ataca e logo em seguida avisa a mira real de volta. A sua camera NAO se mexe.
     */
    public static void silentAttack(MinecraftClient mc, Entity target) {
        Vec3d from = mc.player.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        var net = mc.getNetworkHandler();
        if (net == null) return;

        net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch,
                mc.player.isOnGround(), mc.player.horizontalCollision));
        attack(mc, target);
        net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw(), mc.player.getPitch(),
                mc.player.isOnGround(), mc.player.horizontalCollision));
    }
}
