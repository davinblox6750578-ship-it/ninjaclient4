package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * AutoAnchor: VOCE coloca a ancora de respawn; o modulo faz o resto o mais rapido possivel
 * (Overworld/End, onde a ancora EXPLODE):
 *
 *  1. detecta a ancora que voce acabou de colocar (clique com a ancora na mao + ancora nova ao alcance);
 *  2. poe UMA glowstone (a explosao tem o mesmo poder com 1 ou 4 cargas);
 *  3. no tick seguinte poe um bloco no lado da ancora voltado para voce (protecao);
 *  4. assim que o servidor confirma a carga (e o bloco), clica na ancora com um item que nao e glowstone.
 *
 * Nao coloca ancora sozinho e nao mexe em ancoras que ja existiam. Uma acao por tick, nunca duas
 * interacoes no mesmo tick; o intervalo entre acoes e DELAY_MIN..DELAY_MAX ticks.
 * Sem bloco na hotbar (ou sem apoio ao alcance), so explode com totem na mao secundaria
 * (use junto com AutoTotem) ou a SAFE_DISTANCE+ blocos da ancora.
 * Um bloco ao lado da ancora reduz o dano, nao o elimina.
 */
public class AutoAnchor extends Module {
    private static final double REACH = 4.5;          // alcance para colocar/clicar
    private static final double SAFE_DISTANCE = 4.0;  // sem protecao nem totem, so explode se voce estiver a isso ou mais
    private static final double MIN_HEALTH = 8.0;     // com menos vida que isso, nao age
    private static final int SCAN_RADIUS = 5;         // raio (blocos) em que ancoras ja existentes sao memorizadas
    private static final int ADOPT_TICKS = 10;        // janela entre o seu clique com a ancora e ela aparecer
    private static final int PENDING_TIMEOUT = 12;    // ticks esperando o servidor confirmar
    private static final int GIVE_UP_TICKS = 100;     // desiste da ancora se nada andar
    private static final int DELAY_MIN = 1, DELAY_MAX = 2; // ticks entre acoes; NAO calibrado contra anticheat

    private final Set<BlockPos> known = new HashSet<>();
    private final Random random = new Random();

    private BlockPos mine;       // a ancora que voce colocou e que o modulo opera
    private BlockPos shieldSpot; // onde o bloco de protecao foi pedido
    private boolean chargeSent, shieldTried, shielded, explodeSent;
    private boolean heldLastTick;
    private int useWindow, chargeTimer, shieldTimer, shieldHold, explodeTimer, giveUp, delay;

    public AutoAnchor() {
        super("AutoAnchor", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        release();
        known.clear();
        useWindow = 0;
        delay = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !mc.player.isAlive()) return;

        // so funciona onde a ancora explode (Overworld/End). No Nether ela so carrega/seta spawn.
        if (mc.world.getRegistryKey() == World.NETHER) return;

        if (delay > 0) delay--;
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() < MIN_HEALTH) return;

        trackAnchor();
        if (mine == null) return;

        BlockState state = mc.world.getBlockState(mine);
        if (!state.isOf(Blocks.RESPAWN_ANCHOR) || --giveUp <= 0) { // explodiu, quebrou ou travou
            release();
            return;
        }
        if (delay > 0) return;
        if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(mine)) > REACH) return;

        int charges = state.get(RespawnAnchorBlock.CHARGES);

        // 1) carga: UMA glowstone
        if (!chargeSent && charges == 0) {
            int slot = findSlot(Items.GLOWSTONE);
            if (slot == -1) { release(); return; } // sem glowstone na hotbar
            click(slot, mine, bestFace(mine));
            chargeSent = true;
            chargeTimer = PENDING_TIMEOUT;
            delay = randomDelay();
            return;
        }

        // 2) protecao: uma tentativa, sem esperar a confirmacao da carga
        if (!shieldTried) {
            shieldTried = true;
            if (shield(mine)) return;
        }

        // 3) espera o servidor confirmar bloco e carga
        if (shieldSpot != null && !shielded) {
            if (!mc.world.getBlockState(shieldSpot).isReplaceable()) {
                // o cliente preve o bloco na hora; so confia depois de ~1 ida e volta sem o servidor desfazer
                if (++shieldHold >= confirmTicks()) shielded = true; else return;
            } else {
                shieldHold = 0;
                if (--shieldTimer > 0) return;
                shieldSpot = null; // nao veio: segue sem protecao (cai na checagem de totem/distancia)
            }
        }
        if (charges == 0) {
            if (--chargeTimer <= 0) chargeSent = false; // nao veio: tenta carregar de novo
            return;
        }

        // 4) explode
        if (explodeSent) {
            if (--explodeTimer <= 0) explodeSent = false;
            return;
        }
        if (!shielded && !safeToExplode(mine)) return;
        int slot = findNonGlowstoneSlot();
        if (slot == -1) return;
        click(slot, mine, bestFace(mine));
        explodeSent = true;
        explodeTimer = PENDING_TIMEOUT;
        delay = randomDelay();
    }

    // ------------------------------------------------------- deteccao

    /**
     * Memoriza as ancoras ja existentes perto de voce e adota a primeira ancora NOVA ao alcance
     * que aparecer logo depois de voce clicar com uma ancora na mao.
     */
    private void trackAnchor() {
        // a ultima ancora da pilha some da mao no mesmo tick do clique, entao conta tambem o tick anterior
        boolean holding = mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR);
        if ((holding || heldLastTick) && mc.options.useKey.isPressed()) {
            useWindow = ADOPT_TICKS;
        } else if (useWindow > 0) {
            useWindow--;
        }
        heldLastTick = holding;

        Vec3d eye = mc.player.getEyePos();
        BlockPos origin = mc.player.getBlockPos();
        Set<BlockPos> now = new HashSet<>();
        BlockPos fresh = null;
        for (int dx = -SCAN_RADIUS; dx <= SCAN_RADIUS; dx++) {
            for (int dy = -SCAN_RADIUS; dy <= SCAN_RADIUS; dy++) {
                for (int dz = -SCAN_RADIUS; dz <= SCAN_RADIUS; dz++) {
                    BlockPos p = origin.add(dx, dy, dz);
                    if (!mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR)) continue;
                    now.add(p);
                    if (mine == null && useWindow > 0 && !known.contains(p)
                            && eye.distanceTo(Vec3d.ofCenter(p)) <= REACH) {
                        fresh = p;
                    }
                }
            }
        }
        known.clear();
        known.addAll(now);

        if (fresh != null) {
            release();
            mine = fresh;
            giveUp = GIVE_UP_TICKS;
        }
    }

    private void release() {
        mine = null;
        shieldSpot = null;
        shieldHold = 0;
        chargeSent = false;
        shieldTried = false;
        shielded = false;
        explodeSent = false;
    }

    // ---------------------------------------------------------------- acoes

    /**
     * Bloco de protecao: coloca um bloco no lado horizontal da ancora voltado para voce, barrando a
     * explosao. Nao da para clicar na propria ancora (isso explodiria), entao o bloco e apoiado em
     * outro bloco vizinho. Retorna true se agiu neste tick.
     */
    private boolean shield(BlockPos anchor) {
        Vec3d toMe = mc.player.getEyePos().subtract(Vec3d.ofCenter(anchor));
        Direction face = Direction.getFacing(toMe.x, 0, toMe.z);
        BlockPos spot = anchor.offset(face);
        if (!mc.world.getBlockState(spot).isReplaceable()) { shielded = true; return false; } // ja tem bloco ali
        if (!mc.world.getOtherEntities(null, new Box(spot)).isEmpty()) return false; // alguem ali

        int slot = findShieldSlot();
        if (slot == -1) return false;

        Vec3d eye = mc.player.getEyePos();
        for (Direction d : Direction.values()) {
            BlockPos support = spot.offset(d);
            if (support.equals(anchor)) continue; // nunca clica na ancora
            BlockState st = mc.world.getBlockState(support);
            if (st.isAir() || st.isReplaceable()) continue;
            if (eye.distanceTo(Vec3d.ofCenter(support)) > REACH) continue;
            click(slot, support, d.getOpposite());
            shieldSpot = spot;
            shieldTimer = PENDING_TIMEOUT;
            delay = randomDelay();
            return true;
        }
        return false;
    }

    /** Troca para o slot, interage e devolve o item que estava na mao. */
    private void click(int slot, BlockPos on, Direction face) {
        int previous = mc.player.getInventory().getSelectedSlot();
        if (previous != slot) mc.player.getInventory().setSelectedSlot(slot);

        Vec3d hit = Vec3d.ofCenter(on).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, on, false));
        mc.player.swingHand(Hand.MAIN_HAND);

        if (previous != slot) mc.player.getInventory().setSelectedSlot(previous);
    }

    private boolean safeToExplode(BlockPos anchor) {
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return true;
        return mc.player.getEyePos().distanceTo(Vec3d.ofCenter(anchor)) >= SAFE_DISTANCE;
    }

    // ------------------------------------------------------------ busca

    /** Face da ancora voltada para voce. */
    private Direction bestFace(BlockPos pos) {
        Vec3d d = mc.player.getEyePos().subtract(Vec3d.ofCenter(pos));
        return Direction.getFacing(d.x, d.y, d.z);
    }

    /** Bloco comum para a protecao (nao glowstone, nem ancora, nem blocos que caem). */
    private int findShieldSlot() {
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty() || !(stack.getItem() instanceof net.minecraft.item.BlockItem bi)) continue;
            var b = bi.getBlock();
            if (b == Blocks.GLOWSTONE || b == Blocks.RESPAWN_ANCHOR || b instanceof net.minecraft.block.FallingBlock
                    || b instanceof net.minecraft.block.BlockEntityProvider) continue;
            if (!b.getDefaultState().isSolidBlock(mc.world, BlockPos.ORIGIN)) continue;
            return i;
        }
        return -1;
    }

    private int findSlot(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    /** Slot para explodir: qualquer item que NAO seja glowstone (prefere o que ja esta na mao). */
    private int findNonGlowstoneSlot() {
        int sel = mc.player.getInventory().getSelectedSlot();
        if (!mc.player.getInventory().getStack(sel).isOf(Items.GLOWSTONE)) return sel;
        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getStack(i).isOf(Items.GLOWSTONE)) return i;
        }
        return -1;
    }

    /** Ticks que o bloco de protecao precisa ficar de pe: ping em ticks + 1 (100 ms se o ping for desconhecido). */
    private int confirmTicks() {
        var net = mc.getNetworkHandler();
        var entry = net == null ? null : net.getPlayerListEntry(mc.player.getUuid());
        int ms = entry != null ? entry.getLatency() : 100;
        return Math.min(6, Math.max(1, ms / 50 + 1));
    }

    private int randomDelay() {
        return DELAY_MIN + random.nextInt(DELAY_MAX - DELAY_MIN + 1);
    }
}
