package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/**
 * Caindo de uma altura (fallDistance > 1.5, o minimo do smash no vanilla):
 * mira no jogador ao alcance e da o smash com a clava; depois continua batendo
 * enquanto o alvo estiver ao alcance, esperando a barra de cooldown encher.
 *
 *  - a clava e equipada UMA vez por queda (nao briga com a sua selecao de slot);
 *  - so equipa depois de EQUIP_AIR_TICKS no ar, para pulos normais nao dispararem a troca;
 *  - o smash NAO espera a barra de cooldown (trocar de item zera a barra);
 *  - depois do smash o modulo fica "engajado": cada novo golpe espera a barra
 *    (FOLLOW_UP_COOLDOWN) e vale no ar ou no chao, ate o alvo sair do alcance por ENGAGE_TICKS;
 *  - nao ataca se o alvo estiver bloqueando com escudo;
 *  - nao faz smash planando de elytra (o vanilla nao da o bonus).
 *
 * EQUIP_AIR_TICKS, ENGAGE_TICKS e MIN_GAP_TICKS NAO foram calibrados no jogo.
 */
public class AutoMace extends Module {
    private static final double REACH = 3.0;         // olhos -> caixa do alvo
    private static final double EQUIP_RANGE = 12.0;  // pega a clava quando alguem chega perto
    private static final double MIN_FALL = 1.5;      // queda minima para o smash
    private static final int EQUIP_AIR_TICKS = 12;   // um pulo normal dura ~12 ticks no ar
    private static final int ENGAGE_TICKS = 40;      // tempo sem alvo ao alcance ate encerrar o combo
    private static final int MIN_GAP_TICKS = 10;     // intervalo minimo entre ataques

    enum Attack { NONE, SMASH, FOLLOW_UP }

    private int gap;
    private int airTicks;
    private int engagedTicks;
    private boolean equippedThisFall;
    private boolean smashedThisFall;

    public AutoMace() {
        super("AutoMace", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        gap = 0;
        airTicks = 0;
        engagedTicks = 0;
        equippedThisFall = false;
        smashedThisFall = false;
    }

    /** Decide o tipo de golpe do tick; funcao pura, sem acesso ao jogo. */
    static Attack chooseAttack(boolean onGround, boolean gliding, double fallDistance,
                               boolean smashedThisFall, boolean engaged,
                               boolean cooldownReady, boolean targetBlocking, int gap) {
        if (gap > 0 || targetBlocking) return Attack.NONE;
        if (!onGround && !gliding && !smashedThisFall && fallDistance > MIN_FALL) return Attack.SMASH;
        if (engaged && cooldownReady) return Attack.FOLLOW_UP;
        return Attack.NONE;
    }

    @Override
    public void onTick() {
        if (gap > 0) gap--;
        if (engagedTicks > 0) engagedTicks--;
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !mc.player.isAlive()) return;

        boolean onGround = mc.player.isOnGround();
        if (onGround) {
            airTicks = 0;
            equippedThisFall = false;
            smashedThisFall = false;
        } else {
            airTicks++;
        }
        boolean gliding = isGliding();

        if (!mc.player.getMainHandStack().isOf(Items.MACE)) {
            if (!equippedThisFall && !onGround && !gliding && airTicks >= EQUIP_AIR_TICKS
                    && Combat.nearestPlayer(mc, EQUIP_RANGE) != null) {
                selectMace();
                equippedThisFall = true;
            }
            return;
        }

        PlayerEntity target = Combat.nearestPlayerInReach(mc, REACH);
        if (target == null) return;

        Attack attack = chooseAttack(onGround, gliding, mc.player.fallDistance, smashedThisFall,
                engagedTicks > 0, Combat.cooldownReady(mc), target.isBlocking(), gap);
        if (attack == Attack.NONE) return;

        Combat.aimAt(mc, target, 180f);
        Combat.attack(mc, target);
        if (attack == Attack.SMASH) smashedThisFall = true;
        engagedTicks = ENGAGE_TICKS;
        gap = MIN_GAP_TICKS;
    }

    private void selectMace() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) {
                mc.player.getInventory().setSelectedSlot(i);
                return;
            }
        }
    }

    /** Planando de elytra (nome da pose muda entre mapeamentos; mesma checagem do AutoElytra). */
    private boolean isGliding() {
        if (mc.player.isOnGround()) return false;
        String pose = mc.player.getPose().name();
        return pose.equals("GLIDING") || pose.equals("FALL_FLYING");
    }
}
