package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.VaultBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.VaultBlockEntity;
import net.minecraft.block.enums.VaultState;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Base dos modulos de caixa (vault) das Trial Chambers.
 * Confere TODO tick as caixas num raio de 4 blocos e, no instante em que o
 * item que flutua nela e o item desejado, troca para a chave certa (na hotbar),
 * clica na caixa e devolve o slot.
 *
 *  - ominousVault: true = so caixa suprema; false = so caixa normal;
 *  - wanted: item que dispara o clique;
 *  - key: chave usada na caixa.
 * Cada caixa so abre uma vez por jogador: depois de 3 tentativas na mesma caixa
 * ele para, ate o item exibido mudar.
 */
public abstract class VaultSniper extends Module {
    private static final int RADIUS = 4;      // alcance da fechadura da caixa
    private static final int MAX_ATTEMPTS = 3;

    private final boolean ominousVault;
    private final Item wanted;
    private final Item key;
    private final int retryTicks;

    private int timer;
    private int rescanTimer;
    private final Map<BlockPos, Integer> attempts = new HashMap<>();
    // vaults proximas guardadas em cache: assim a checagem a cada frame e barata
    private final List<BlockPos> nearby = new ArrayList<>();

    // todas as instancias (AutoVaultSuper, PotVault): o mixin de rede avisa todas de uma vez
    private static final List<VaultSniper> INSTANCES = new ArrayList<>();

    protected VaultSniper(String name, boolean ominousVault, Item wanted, Item key, int retryTicks) {
        super(name, Category.WORLD);
        this.ominousVault = ominousVault;
        this.wanted = wanted;
        this.key = key;
        this.retryTicks = retryTicks;
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
        INSTANCES.add(this);

        // checa tambem a CADA FRAME (nao so a cada tick de 50 ms): o servidor troca o item
        // exibido rapido, entao quanto antes o clique sair, maior a chance de pegar o item certo
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of("ninjaclient", "vault_" + name.toLowerCase()),
                (ctx, tickCounter) -> snipe());
    }

    @Override
    public void onDisable() {
        attempts.clear();
        nearby.clear();
        timer = 0;
        rescanTimer = 0;
    }

    @Override
    public void onTick() {
        if (timer > 0) timer--;
        rescan(); // todo tick: a caixa e achada assim que voce chega perto
        snipe();
    }

    /**
     * Chamado pelo mixin de rede NO INSTANTE em que o pacote da caixa chega (antes do proximo
     * frame/tick): e o mais rapido possivel de reagir ao item exibido. Nao da pra prever o
     * proximo item (e sorteio do servidor), entao o ganho esta em nao perder tempo.
     */
    public static void onVaultPacket() {
        for (VaultSniper m : INSTANCES) {
            if (!m.isEnabled()) continue;
            net.minecraft.client.MinecraftClient c = net.minecraft.client.MinecraftClient.getInstance();
            if (c.player == null || c.world == null) continue;
            if (m.nearby.isEmpty()) m.rescan();
            m.snipe();
        }
    }

    /** Procura as vaults do tipo certo no raio (feito so a cada 5 ticks). */
    private void rescan() {
        nearby.clear();
        BlockPos origin = mc.player.getBlockPos();
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dy = -RADIUS; dy <= RADIUS; dy++) {
                for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                    BlockPos p = origin.add(dx, dy, dz);
                    if (mc.world.getBlockEntity(p) instanceof VaultBlockEntity) nearby.add(p);
                }
            }
        }
    }

    /** Roda todo tick e todo frame: clica assim que o item exibido for o desejado. */
    private void snipe() {
        if (!isEnabled() || mc.player == null || mc.world == null) return;
        if (timer > 0 || mc.currentScreen != null) return;
        for (BlockPos pos : nearby) {
            if (handleVault(pos)) return; // uma acao por vez
        }
    }

    /** Retorna true se tentou abrir a caixa neste tick. */
    private boolean handleVault(BlockPos pos) {
        BlockEntity be = mc.world.getBlockEntity(pos);
        if (!(be instanceof VaultBlockEntity vault)) return false;

        BlockState state = mc.world.getBlockState(pos);
        if (!(state.getBlock() instanceof VaultBlock)) return false;
        if (state.get(VaultBlock.OMINOUS) != ominousVault) return false;
        if (state.get(VaultBlock.VAULT_STATE) != VaultState.ACTIVE) return false;

        var shared = vault.getSharedData();
        boolean match = shared.hasDisplayItem() && shared.getDisplayItem().isOf(wanted);
        if (!match) {
            attempts.remove(pos); // item mudou: libera novas tentativas
            return false;
        }

        if (attempts.getOrDefault(pos, 0) >= MAX_ATTEMPTS) return false;
        if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(pos)) > RADIUS + 0.5) return false;

        int keySlot = findKeySlot();
        if (keySlot == -1) return false; // sem a chave certa na hotbar

        int previous = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(keySlot);

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false));
        mc.player.swingHand(Hand.MAIN_HAND);

        mc.player.getInventory().setSelectedSlot(previous);

        attempts.merge(pos, 1, Integer::sum);
        timer = retryTicks;
        return true;
    }

    private int findKeySlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(key)) return i;
        }
        return -1;
    }
}
