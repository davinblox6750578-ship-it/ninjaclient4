package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * ESP de jogadores: liga o contorno brilhante (glow) so no seu client.
 * O contorno aparece atraves das paredes e nada e enviado ao servidor.
 */
public class ESP extends Module {
    public ESP() {
        super("ESP", Category.RENDER);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onTick() {
        // reaplica todo tick, porque o servidor pode resetar o estado
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof PlayerEntity p && p != mc.player) {
                p.setGlowing(true);
            }
        }
    }

    @Override
    public void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof PlayerEntity p && p != mc.player) {
                p.setGlowing(false);
            }
        }
    }
}
