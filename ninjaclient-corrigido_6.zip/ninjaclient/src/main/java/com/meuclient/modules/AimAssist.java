package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Mira "grudada": trava no inimigo e acompanha cada movimento dele.
 * Parte do corpo configuravel: clique com o botao DIREITO no menu para trocar
 * entre Cabeca, Peito e Perna.
 */
public class AimAssist extends Module {
    public enum Part {
        HEAD("Cabeca"), CHEST("Peito"), LEGS("Perna");
        public final String label;
        Part(String label) { this.label = label; }
    }

    private static final double LOCK_RANGE = 6.0;     // distancia para travar no alvo
    private static final double RELEASE_RANGE = 8.0;  // so solta se passar disso
    private static final float TURN_SPEED = 45f;      // graus por tick (alto = gruda forte)

    private Part part = Part.CHEST;
    private PlayerEntity locked;

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public String suffix() { return " [" + part.label + "]"; }

    @Override
    public void onRightClick() {
        Part[] all = Part.values();
        part = all[(part.ordinal() + 1) % all.length];
        com.meuclient.Config.markDirty();
    }

    @Override
    public String getExtra() { return part.name(); }

    @Override
    public void setExtra(String value) {
        try { part = Part.valueOf(value); } catch (IllegalArgumentException ignored) {}
    }

    @Override
    public void onDisable() { locked = null; }

    @Override
    public void onTick() {
        if (locked != null && (!locked.isAlive() || locked.isRemoved()
                || mc.player.distanceTo(locked) > RELEASE_RANGE)) {
            locked = null;
        }
        if (locked == null) locked = Combat.nearestPlayer(mc, LOCK_RANGE);
        if (locked == null) return;

        // ponto a mirar + 1 tick de antecipacao do movimento do alvo
        Vec3d aim = pointOf(locked).add(locked.getVelocity());
        Combat.aimAtPos(mc, aim, TURN_SPEED);
    }

    private Vec3d pointOf(PlayerEntity t) {
        double h = t.getHeight();
        double y = switch (part) {
            case HEAD -> h * 0.92;   // altura dos olhos
            case CHEST -> h * 0.65;  // peito
            case LEGS -> h * 0.25;   // perna
        };
        return new Vec3d(t.getX(), t.getY() + y, t.getZ());
    }
}
