package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Config;
import com.meuclient.Module;

/**
 * FastBreak: quebra blocos mais rapido segurando o botao de ataque.
 *  1. tira o atraso de 5 ticks entre um bloco e o proximo;
 *  2. manda o "bloco quebrado" ao servidor quando o progresso chega no limite do modo, em vez de 100%.
 *
 * Modos (clique com o botao DIREITO no menu para trocar):
 *  - Seguro (0.70): o servidor vanilla aceita o fim da quebra com 70% do progresso, entao este modo
 *    nao precisa enganar o servidor;
 *  - Rapido (0.50) e Maximo (0.25): abaixo do que o servidor vanilla aceita. So funcionam em servidor
 *    que nao valida; nos outros o bloco volta (bloco fantasma). NAO calibrados em servidor nenhum.
 *
 * Durabilidade: o servidor gasta 1 por bloco que realmente quebra, nao por tempo. Quebra recusada pelo
 * servidor nao gasta durabilidade.
 */
public class FastBreak extends Module {
    public enum Mode {
        SAFE("Seguro", 0.70f), FAST("Rapido", 0.50f), MAX("Maximo", 0.25f);
        public final String label;
        public final float threshold;
        Mode(String label, float threshold) { this.label = label; this.threshold = threshold; }
    }

    private Mode mode = Mode.SAFE;

    public FastBreak() {
        super("FastBreak", Category.RENDER);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public String suffix() { return " [" + mode.label + "]"; }

    @Override
    public void onRightClick() {
        Mode[] all = Mode.values();
        mode = all[(mode.ordinal() + 1) % all.length];
        Config.markDirty();
    }

    @Override
    public String getExtra() { return mode.name(); }

    @Override
    public void setExtra(String value) {
        try { mode = Mode.valueOf(value); } catch (IllegalArgumentException ignored) {}
    }

    /** Progresso a gravar para o vanilla terminar a quebra no proximo tick; o mesmo valor = nada a fazer. */
    static float boostedProgress(boolean breaking, float progress, float threshold) {
        if (!breaking || !(progress >= threshold) || progress >= 1.0f) return progress;
        return 1.0f;
    }

    @Override
    public void onTick() {
        var im = mc.interactionManager;
        if (mc.player == null || im == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) return;

        im.blockBreakingCooldown = 0;
        im.currentBreakingProgress = boostedProgress(im.breakingBlock, im.currentBreakingProgress, mode.threshold);
    }
}
