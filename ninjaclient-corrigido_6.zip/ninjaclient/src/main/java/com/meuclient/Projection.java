package com.meuclient;

import net.minecraft.client.MinecraftClient;

/**
 * FOV REAL usado pelo jogo para desenhar o mundo. O valor das opcoes (options.getFov)
 * nao e o que e renderizado: sprint, efeito de velocidade etc. alargam o FOV. Se os ESPs usarem
 * o valor das opcoes, a caixa/linha/vida saem deslocadas e maiores que o boneco.
 * O GameRendererMixin guarda aqui o FOV de cada frame; se o mixin nao pegar, usa o das opcoes.
 */
public final class Projection {
    private Projection() {}

    /** Preenchido pelo GameRendererMixin (graus). <= 0 = ainda nao capturado. */
    public static volatile float worldFov = -1f;

    /** tan(FOV vertical / 2) para projetar pontos do mundo na tela. */
    public static double tanHalfFov(MinecraftClient mc) {
        float f = worldFov;
        double deg = (f > 1f && f < 170f) ? f : mc.options.getFov().getValue();
        return Math.tan(Math.toRadians(deg) / 2.0);
    }
}
